package com.example.hiking_route_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
